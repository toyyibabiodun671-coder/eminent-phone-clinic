import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const supabase = await createClient()

    const { data, error } = await supabase
      .from('sales')
      .insert({
        amount: Number(body.amount),
        type: body.type,
        payment_method: body.payment_method,
        customer_id: body.customer_id || null,
        repair_job_id: body.repair_job_id || null,
        device_id: body.device_id || null,
        description: body.description || null,
      })
      .select('*')
      .single()

    if (error) throw new Error(error.message)

    return NextResponse.json({ success: true, sale: data })
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 400 })
  }
}