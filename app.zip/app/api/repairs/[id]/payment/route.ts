import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'

export async function POST(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params
  const result = await getCurrentProfile()
  const profile = result?.profile

  if (!profile) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 })
  }

  const body = await request.json()
  const amount = Number(body.amount)
  const paymentMethod = body.payment_method as string
  const description = body.description as string | undefined

  if (!amount || amount <= 0) {
    return NextResponse.json({ error: 'Enter a valid payment amount.' }, { status: 400 })
  }

  const allowedMethods = ['cash', 'transfer', 'pos', 'other']
  if (!allowedMethods.includes(paymentMethod)) {
    return NextResponse.json({ error: 'Invalid payment method.' }, { status: 400 })
  }

  const supabase = await createClient()

  const { data: repair, error: repairError } = await supabase
    .from('repair_jobs')
    .select('id, repair_cost, technician_id, customer_id, device_id')
    .eq('id', id)
    .single()

  if (repairError || !repair) {
    return NextResponse.json({ error: 'Repair job not found.' }, { status: 404 })
  }

  const isAdmin =
    profile.role === 'admin' ||
    (profile.role as string) === 'manager' ||
    profile.role === 'owner'
  const isAssignedTechnician = repair.technician_id === profile.id

  if (!isAdmin && !isAssignedTechnician) {
    return NextResponse.json(
      { error: 'You are not allowed to record payment for this repair.' },
      { status: 403 }
    )
  }

  const { data: existingPayments } = await supabase
    .from('sales')
    .select('amount')
    .eq('repair_job_id', id)
    .in('type', ['repair', 'deposit', 'balance'])

  type PaymentRow = { amount: number | string }
  const payments = (existingPayments as PaymentRow[]) || []
  const currentPaid = payments.reduce((sum, p) => sum + Number(p.amount), 0)
  const repairCost = Number(repair.repair_cost)
  const outstanding = Math.max(repairCost - currentPaid, 0)

  if (amount > outstanding) {
    return NextResponse.json(
      {
        error: `Payment cannot exceed the outstanding balance of ₦${outstanding.toLocaleString()}.`,
      },
      { status: 400 }
    )
  }

  const newAmountPaid = currentPaid + amount

  try {
    const { error: saleError } = await supabase.from('sales').insert({
      amount: amount,
      type: amount === outstanding ? 'balance' : 'repair',
      payment_method: paymentMethod,
      customer_id: repair.customer_id,
      repair_job_id: repair.id,
      device_id: repair.device_id,
      description: description?.trim() || `Payment for repair ${repair.id.slice(0, 8)}`,
    })

    if (saleError) throw new Error(saleError.message)
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : 'Failed to record sale'
    return NextResponse.json({ error: message }, { status: 500 })
  }

  const { error: repairUpdateError } = await supabase
    .from('repair_jobs')
    .update({
      amount_paid: newAmountPaid,
      updated_at: new Date().toISOString(),
    })
    .eq('id', repair.id)

  if (repairUpdateError) {
    return NextResponse.json({ error: repairUpdateError.message }, { status: 500 })
  }

  return NextResponse.json({
    success: true,
    amount_paid: newAmountPaid,
    outstanding: repairCost - newAmountPaid,
  })
}