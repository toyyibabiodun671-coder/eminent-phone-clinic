import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'

const allowedStatuses = [
  'pending',
  'diagnosing',
  'in_repair',
  'waiting_parts',
  'completed',
  'collected',
  'cancelled',
] as const

// ✅ THIS IS WHAT YOU WERE MISSING — workflow map
const validTransitions: Record<string, string[]> = {
  pending: ['diagnosing', 'cancelled'],
  diagnosing: ['in_repair', 'waiting_parts', 'cancelled'],
  in_repair: ['waiting_parts', 'completed', 'cancelled'],
  waiting_parts: ['in_repair', 'completed', 'cancelled'],
  completed: ['collected'],
  collected: [],
  cancelled: [],
}

export async function PATCH(
  request: Request,
  context: {
    params: Promise<{ id: string }>
  }
) {
  const { id } = await context.params

  const result = await getCurrentProfile()
  const profile = result?.profile

  if (!profile) {
    return NextResponse.json(
      { error: 'Not authenticated.' },
      { status: 401 }
    )
  }

  const body = await request.json()
  const newStatus = body.status

  if (!allowedStatuses.includes(newStatus)) {
    return NextResponse.json(
      { error: 'Invalid repair status.' },
      { status: 400 }
    )
  }

  const supabase = await createClient()

  const { data: repair, error: repairError } = await supabase
   .from('repair_jobs')
   .select('id, technician_id, status')
   .eq('id', id)
   .single()

  if (repairError ||!repair) {
    return NextResponse.json(
      { error: 'Repair job not found.' },
      { status: 404 }
    )
  }

  const isAdmin = profile.role === 'admin' || profile.role === 'manager'
  const isAssignedTechnician = repair.technician_id === profile.id

  if (!isAdmin &&!isAssignedTechnician) {
    return NextResponse.json(
      { error: 'You are not allowed to update this repair.' },
      { status: 403 }
    )
  }

  // Apprentice cannot collect or cancel
  if (
   !isAdmin &&
    (newStatus === 'collected' || newStatus === 'cancelled')
  ) {
    return NextResponse.json(
      { error: 'Apprentices cannot mark as collected or cancelled.' },
      { status: 403 }
    )
  }

  // ✅ WORKFLOW ENFORCEMENT — THIS FIXES YOUR TEST
  const currentStatus = repair.status
  const allowedNext = validTransitions[currentStatus] || []

  // Admin can cancel from anywhere, but still cannot skip steps otherwise
  const isAdminCancelOverride = isAdmin && newStatus === 'cancelled'

  if (!isAdminCancelOverride &&!allowedNext.includes(newStatus)) {
    return NextResponse.json(
      { error: `Invalid status transition from ${currentStatus} to ${newStatus}.` },
      { status: 400 }
    )
  }

  const { error: updateError } = await supabase
   .from('repair_jobs')
   .update({
      status: newStatus,
      updated_at: new Date().toISOString(),
    })
   .eq('id', id)

  if (updateError) {
    return NextResponse.json(
      { error: updateError.message },
      { status: 500 }
    )
  }

  return NextResponse.json({
    success: true,
    status: newStatus,
  })
}