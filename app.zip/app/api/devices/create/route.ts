import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'

export async function POST(request: Request) {
  await getCurrentProfile()

  const formData = await request.formData()

  const customerId = String(formData.get('customer_id') || '').trim()
  const deviceType = String(formData.get('device_type') || '').trim()
  const brand = String(formData.get('brand') || '').trim()
  const model = String(formData.get('model') || '').trim()
  const imei = String(formData.get('imei') || '').trim()
  const serialNumber = String(formData.get('serial_number') || '').trim()
  const color = String(formData.get('color') || '').trim()
  const conditionNotes = String(formData.get('condition_notes') || '').trim()

  if (!customerId || !brand || !model) {
    return NextResponse.json(
      { error: 'Customer, brand and model are required.' },
      { status: 400 }
    )
  }

  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  const { error } = await supabase.from('devices').insert({
    customer_id: customerId,
    device_type: deviceType || null,
    brand,
    model,
    imei: imei || null,
    serial_number: serialNumber || null,
    color: color || null,
    condition_notes: conditionNotes || null,
    created_by: user?.id ?? null,
  })

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 400 })
  }

  return NextResponse.redirect(new URL(`/customers/${customerId}`, request.url), 303)
}