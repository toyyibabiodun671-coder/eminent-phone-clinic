'use client'

import { FormEvent, useState } from 'react'
import { createClient } from '@/lib/supabase/client'

export default function LoginPage() {
  const supabase = createClient()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setLoading(true)

    // FIXED: renamed to authError - no more orange underline
    const { error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (authError) {
      setError(authError.message)
      setLoading(false)
      return
    }

    window.location.href = '/dashboard'
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-[#EFF6FF] p-6">
      <div className="w-full max-w-md">
        {/* BLUE HEADER WITH CODE LOGO - NO IMAGE */}
        <div className="rounded-2xl bg-[#2563EB] p-8 shadow-lg text-center">
          
          {/* EP LOGO BUILT WITH CODE - NO BACKGROUND */}
          <div className="mx-auto flex flex-col items-center">
            {/* Gold Roof */}
            <div className="h-3 w-16 bg-gradient-to-r from-yellow-600 via-yellow-300 to-yellow-600" style={{clipPath: 'polygon(0 100%, 50% 0, 100% 100%)'}}></div>
            {/* EP Letters */}
            <div className="mt-2 flex gap-1 font-black text-4xl tracking-tighter">
              <span className="text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.3)]">E</span>
              <span className="bg-gradient-to-b from-gray-100 to-gray-400 bg-clip-text text-transparent">P</span>
            </div>
            <div className="mt-1 h-1 w-12 rounded bg-yellow-400/80"></div>
          </div>

          <h1 className="mt-4 text-2xl font-bold text-white tracking-tight">
            Eminent Phone Clinic
          </h1>
          <p className="mt-1.5 text-sm text-blue-100 font-medium">
            Repair Management System
          </p>
        </div>

        <div className="mt-5 rounded-2xl border border-blue-200 bg-white p-8 shadow-sm">
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="mb-2 block text-sm font-medium text-[#1D4ED8]">Email</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full rounded-lg border border-blue-200 bg-white px-4 py-3 outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100" placeholder="admin@example.com" />
            </div>
            <div>
              <label className="mb-2 block text-sm font-medium text-[#1D4ED8]">Password</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="w-full rounded-lg border border-blue-200 bg-white px-4 py-3 outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100" placeholder="Enter your password" />
            </div>
            {error && <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-600">{error}</div>}
            <button type="submit" disabled={loading} className="w-full rounded-lg bg-[#2563EB] px-4 py-3 font-semibold text-white shadow-md hover:bg-blue-700 disabled:opacity-50 transition-all">
              {loading ? 'Signing in...' : 'Sign in'}
            </button>
          </form>
        </div>
      </div>
    </main>
  )
}