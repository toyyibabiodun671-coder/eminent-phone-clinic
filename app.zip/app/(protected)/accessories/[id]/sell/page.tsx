import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'
import { redirect } from 'next/navigation'

export default async function SellAccessoryPage({ params }: { params: Promise<{ id: string }> }) {
  const { id: paramId } = await params
  await getCurrentProfile()
  const supabase = await createClient()

  const { data: acc } = await supabase.from('accessories').select('*').eq('id', paramId).single()
  if (!acc) return <div className="p-6">Accessory not found in Supabase — ID: {paramId}</div>

  async function sellAccessory(formData: FormData) {
    'use server'
    const supabase = await createClient()
    await getCurrentProfile()
    const id = String(formData.get('id'))
    const qty = Number(formData.get('quantity'))

    const { data: accessory } = await supabase.from('accessories').select('*').eq('id', id).single()
    if (!accessory) throw new Error('Not found')
    if (qty > accessory.stock_quantity) throw new Error(`Only ${accessory.stock_quantity} in stock`)

    await supabase.from('accessories').update({ stock_quantity: accessory.stock_quantity - qty }).eq('id', id)
    redirect('/accessories')
  }

  return (
    <div className="p-6">
      <div className="mx-auto max-w-md rounded-2xl border bg-white p-6 shadow-sm">
        <h1 className="text-xl font-bold">Sell {acc.name}</h1>
        <p className="text-sm text-slate-500">Stock: {acc.stock_quantity} | Price: ₦{acc.selling_price}</p>
        <form action={sellAccessory} className="mt-6 space-y-4">
          <input type="hidden" name="id" value={acc.id} />
          <input name="quantity" type="number" min={1} max={acc.stock_quantity} defaultValue={1} required className="w-full rounded-xl border px-4 py-3" />
          <button className="w-full rounded-xl bg-black py-3 text-white font-semibold">Confirm Sale</button>
        </form>
      </div>
    </div>
  )
}