import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'
import { redirect } from 'next/navigation'

export default async function EditAccessoryPage({ params }: { params: Promise<{ id: string }> }) {
  const { id: paramId } = await params
  await getCurrentProfile()
  const supabase = await createClient()

  const { data: acc } = await supabase
    .from('accessories')
    .select('*')
    .eq('id', paramId)
    .single()

  if (!acc) return <div className="p-6">Not found — ID: {paramId}. Check Supabase table has this row.</div>

  async function updateAccessory(formData: FormData) {
    'use server'
    const supabase = await createClient()
    await getCurrentProfile()
    const id = String(formData.get('id'))
    const name = String(formData.get('name')).trim()
    const category = String(formData.get('category')).trim()
    const selling_price = Number(formData.get('selling_price'))
    const stock_quantity = Number(formData.get('stock_quantity'))

    await supabase.from('accessories').update({
      name,
      category,
      selling_price,
      stock_quantity,
    }).eq('id', id)

    redirect('/accessories')
  }

  return (
    <div className="p-6">
      <div className="mx-auto max-w-xl rounded-2xl border bg-white p-6 shadow-sm">
        <h1 className="text-xl font-bold">Edit {acc.name}</h1>
        <form action={updateAccessory} className="mt-6 space-y-4">
          <input type="hidden" name="id" value={acc.id} />
          <div>
            <label className="text-sm font-semibold">Name</label>
            <input name="name" defaultValue={acc.name} required className="w-full rounded-xl border px-4 py-3" />
          </div>
          <select name="category" defaultValue={acc.category} className="w-full rounded-xl border px-4 py-3">
            <option value="charger">Charger</option>
            <option value="cable">Cable</option>
            <option value="case">Case</option>
            <option value="screen_guard">Screen Guard</option>
            <option value="battery">Battery</option>
            <option value="other">Other</option>
            <option value="general">General</option>
          </select>
          <div>
            <label className="text-sm font-semibold">Selling Price</label>
            <input name="selling_price" type="number" defaultValue={acc.selling_price} required className="w-full rounded-xl border px-4 py-3" />
          </div>
          <div>
            <label className="text-sm font-semibold">Stock</label>
            <input name="stock_quantity" type="number" defaultValue={acc.stock_quantity} required className="w-full rounded-xl border px-4 py-3" />
          </div>
          <button className="w-full rounded-xl bg-[#2563EB] py-3 text-white font-semibold">Update</button>
        </form>
      </div>
    </div>
  )
}