import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'
import { redirect } from 'next/navigation'

export default async function NewAccessoryPage() {
  await getCurrentProfile()

  async function createAccessory(formData: FormData) {
    'use server'
    const supabase = await createClient()
    await getCurrentProfile()
    
    const name = String(formData.get('name') ?? '').trim()
    const selling_price = Number(formData.get('selling_price'))
    const stock_quantity = Number(formData.get('stock_quantity') ?? 0)

    if (!name) throw new Error('Name is required')
    if (selling_price <= 0) throw new Error('Selling price must be > 0')
    if (stock_quantity < 0) throw new Error('Stock cannot be negative')

    const { error } = await supabase.from('accessories').insert({
      name,
      selling_price,
      stock_quantity,
      active: true,
    })

    if (error) {
      console.log('INSERT ACCESSORY ERROR:', error)
      throw new Error(error.message)
    }

    redirect('/accessories')
  }

  return (
    <div className="p-6">
      <div className="mx-auto max-w-xl rounded-2xl border border-blue-200 bg-white p-6 shadow-sm">
        <h1 className="text-xl font-bold text-[#1E3A8A]">Add Accessory</h1>
        <p className="mt-1 text-sm text-slate-500">Add new item to inventory</p>

        <form action={createAccessory} className="mt-6 space-y-4">
          <div>
            <label className="text-sm font-semibold">Name</label>
            <input name="name" required placeholder="e.g. USB Cable" className="mt-1 w-full rounded-xl border px-4 py-3" />
          </div>

          <div>
            <label className="text-sm font-semibold">Selling Price (₦)</label>
            <input name="selling_price" type="number" min={1} required className="mt-1 w-full rounded-xl border px-4 py-3" />
          </div>

          <div>
            <label className="text-sm font-semibold">Stock Quantity</label>
            <input name="stock_quantity" type="number" min={0} defaultValue={0} required className="mt-1 w-full rounded-xl border px-4 py-3" />
          </div>

          <button className="w-full rounded-xl bg-[#2563EB] py-3 text-sm font-semibold text-white hover:bg-[#1D4ED8]">
            Save Accessory
          </button>
        </form>
      </div>
    </div>
  )
}