import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'
import Link from 'next/link'

type Accessory = {
  id: string
  name: string
  selling_price: number
  stock_quantity: number
  category: string
  cost_price?: number
}

export const dynamic = 'force-dynamic'

export default async function AccessoriesPage() {
  await getCurrentProfile()
  const supabase = await createClient()

  const { data: accessories, error } = await supabase
   .from('accessories')
   .select('*')
   .order('created_at', { ascending: false })

  if (error) {
    return <div className="p-6">Error: {error.message}</div>
  }

  return (
    <div className="min-h-screen bg-[#EFF6FF] -m-6 p-6">
      <div className="rounded-2xl bg-[#2563EB] p-6 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/20 text-white font-bold">A</div>
            <div>
              <h1 className="text-2xl font-bold text-white">Accessories</h1>
              <p className="mt-1 text-sm text-blue-100">{accessories?.length || 0} items in stock</p>
            </div>
          </div>
          <Link href="/accessories/new" className="rounded-xl bg-white px-5 py-2.5 text-sm font-bold text-[#2563EB] shadow hover:bg-blue-50">
            + Add
          </Link>
        </div>
      </div>

      <div className="mt-6 grid gap-3">
        {(!accessories || accessories.length === 0) && (
          <div className="rounded-2xl border border-blue-200 bg-white p-10 text-center shadow-sm">
            <p className="text-sm font-semibold text-[#1E3A8A]">No accessories yet</p>
            <p className="mt-1 text-xs text-slate-500">Add your first USB cable, pouch, charger etc</p>
            <Link href="/accessories/new" className="mt-4 inline-block rounded-xl bg-[#2563EB] px-5 py-2.5 text-sm font-bold text-white">Add Accessory</Link>
          </div>
        )}

        {accessories?.map((acc: Accessory) => (
          <div key={acc.id} className="flex items-center justify-between rounded-2xl border border-blue-200 bg-white p-4 shadow-sm transition-all hover:shadow-md hover:border-blue-300">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#EFF6FF] font-bold text-[#2563EB]">{acc.name[0]?.toUpperCase()}</div>
              <div>
                <div className="font-bold text-[#1E3A8A]">{acc.name}</div>
                <div className="mt-0.5 flex items-center gap-2 text-xs">
                  <span className="rounded-full bg-blue-50 px-2 py-0.5 font-semibold text-[#2563EB]">₦{Number(acc.selling_price).toLocaleString()}</span>
                  <span className={`rounded-full px-2 py-0.5 font-semibold ${acc.stock_quantity <= 3? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>Stock: {acc.stock_quantity}</span>
                  <span className="text-slate-400">{acc.category}</span>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Link href={`/accessories/${acc.id}/sell`} className="rounded-xl bg-black px-4 py-2 text-xs font-bold text-white hover:bg-zinc-800">Sell</Link>
              <Link href={`/accessories/${acc.id}/edit`} className="rounded-xl border border-blue-200 bg-[#EFF6FF] px-4 py-2 text-xs font-bold text-[#1D4ED8]">Edit</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}