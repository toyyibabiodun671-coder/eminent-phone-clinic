import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'
import SellForm from './sell-form'

export default async function SellAccessoryPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  await getCurrentProfile()
  const supabase = await createClient()

  const { data: acc } = await supabase.from('accessories').select('*').eq('id', id).single()
  if (!acc) return <div className="p-6">Not found: {id}</div>

  return (
    <div className="min-h-screen bg-[#EFF6FF] -m-6 p-6">
      <div className="mx-auto max-w-md">
        <div className="rounded-2xl bg-[#2563EB] p-6 shadow-lg">
          <h1 className="text-xl font-bold text-white">Sell Accessory</h1>
          <p className="mt-1 text-sm text-blue-100">Eminent Blue • {acc.name}</p>
        </div>
        <div className="mt-6 rounded-2xl border border-blue-200 bg-white p-6 shadow-sm">
          <SellForm acc={acc} />
        </div>
      </div>
    </div>
  )
}