
'use client'

import { useState } from 'react'
import { recordSale } from '@/lib/transactions'
import Link from 'next/link'

type Accessory = {
  id: string
  name: string
  selling_price: number
  stock_quantity: number
}

type SaleData = {
  name: string
  qty: number
  total: number
  method: string
}

function SellSuccessPopup({
  open,
  onClose,
  data,
}: {
  open: boolean
  onClose: () => void
  data: SaleData | null
}) {
  if (!open || !data) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
      <div className="w-full max-w-sm rounded-[24px] bg-white p-6 shadow-2xl">
        <div className="flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full bg-gray-100 px-3 py-1"
            aria-label="Close success message"
          >
            X
          </button>
        </div>

        <div className="flex flex-col items-center text-center">
          <div className="success-check flex h-16 w-16 items-center justify-center rounded-full bg-green-600 text-3xl text-white">
            ✓
          </div>

          <h2 className="mt-4 text-xl font-bold text-green-700">
            Done!
          </h2>
          <p className="mt-1 text-sm text-gray-500">
            Accessory sale recorded successfully.
          </p>

          <div className="mt-6 w-full rounded-2xl border border-green-100 bg-green-50 p-4 text-left">
            <div className="flex justify-between gap-3 text-sm">
              <span className="text-gray-500">Item</span>
              <span className="text-right font-semibold">{data.name}</span>
            </div>

            <div className="mt-2 flex justify-between text-sm">
              <span className="text-gray-500">Quantity</span>
              <span className="font-semibold">{data.qty}x</span>
            </div>

            <div className="mt-3 flex justify-between border-t border-green-200 pt-3">
              <span className="font-bold">Total</span>
              <span className="text-lg font-bold text-green-700">
                ₦{data.total.toLocaleString()}
              </span>
            </div>

            <div className="mt-2 flex justify-between text-sm">
              <span className="text-gray-500">Payment</span>
              <span className="font-semibold uppercase">{data.method}</span>
            </div>
          </div>

          <div className="mt-6 grid w-full grid-cols-2 gap-3">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border py-3 text-sm font-semibold"
            >
              Continue
            </button>

            <Link
              href="/sales"
              className="flex items-center justify-center rounded-xl bg-[#2563EB] py-3 text-sm font-semibold text-white"
            >
              Sales History
            </Link>
          </div>
        </div>
      </div>

      <style jsx>{`
        .success-check {
          animation: check-pop 900ms ease-in-out both;
        }

        @keyframes check-pop {
          0% {
            opacity: 0;
            transform: scale(0.65);
          }
          60% {
            opacity: 1;
            transform: scale(1.08);
          }
          100% {
            opacity: 1;
            transform: scale(1);
          }
        }
      `}</style>
    </div>
  )
}

export default function SellForm({ acc }: { acc: Accessory }) {
  const [qty, setQty] = useState(
    Math.max(1, Math.min(2, acc.stock_quantity))
  )
  const [method, setMethod] = useState<'cash' | 'transfer' | 'pos'>('cash')
  const [loading, setLoading] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [saleData, setSaleData] = useState<SaleData | null>(null)

  // Keep the same ID after an error so a retry cannot create a second sale.
  const [saleRequestId, setSaleRequestId] = useState('')

  const total = qty * Number(acc.selling_price)
  const outOfStock = acc.stock_quantity < 1

  async function handleSell(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()

    if (loading) return

    if (outOfStock) {
      alert('This accessory is out of stock.')
      return
    }

    if (!Number.isInteger(qty) || qty < 1) {
      alert('Enter a valid quantity of at least 1.')
      return
    }

    if (qty > acc.stock_quantity) {
      alert(`Only ${acc.stock_quantity} in stock. Refresh the page to get the latest stock.`)
      return
    }

    if (!Number.isFinite(Number(acc.selling_price)) || Number(acc.selling_price) <= 0) {
      alert('This accessory has an invalid selling price. Please contact the admin.')
      return
    }

    setLoading(true)

    const requestId = saleRequestId || crypto.randomUUID()
    setSaleRequestId(requestId)

    try {
      await recordSale({
        amount: total,
        transaction_type: 'accessory_sale',
        payment_method: method,
        description: `${qty}x ${acc.name}`,
        accessory_id: acc.id,
        quantity: qty,
        request_id: requestId,
      })

      setSaleData({
        name: acc.name,
        qty,
        total,
        method,
      })
      setShowSuccess(true)

      // Prepare a fresh ID for the next sale.
      setSaleRequestId(crypto.randomUUID())
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Could not confirm the sale.'

      console.error('Accessory sale error:', err)
      alert(
        `Sale was not confirmed: ${message}\n\nDo not make another sale yet if your network disconnected. Retry this same submission first so the system can check the original request.`
      )
    } finally {
      setLoading(false)
    }
  }

  function closeSuccess() {
    setShowSuccess(false)
    window.location.reload()
  }

  return (
    <>
      <form onSubmit={handleSell} className="mt-6 space-y-5">
        {outOfStock && (
          <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">
            This accessory is out of stock and cannot be sold.
          </div>
        )}

        <div>
          <label htmlFor="sale-quantity" className="text-[13px] font-semibold">
            Quantity
          </label>

          <div className="mt-2 flex items-center gap-3">
            <button
              type="button"
              disabled={loading || outOfStock || qty <= 1}
              onClick={() => setQty((current) => Math.max(1, current - 1))}
              className="h-12 w-12 rounded-xl border disabled:opacity-40"
              aria-label="Decrease quantity"
            >
              -
            </button>

            <input
              id="sale-quantity"
              type="number"
              min={1}
              max={acc.stock_quantity}
              step={1}
              value={qty}
              disabled={loading || outOfStock}
              onChange={(e) => {
                const value = Number(e.target.value)
                if (Number.isInteger(value) && value >= 1) {
                  setQty(Math.min(value, Math.max(1, acc.stock_quantity)))
                }
              }}
              className="h-12 min-w-0 flex-1 rounded-xl border bg-slate-50 px-4 text-center font-bold"
              required
            />

            <button
              type="button"
              disabled={loading || outOfStock || qty >= acc.stock_quantity}
              onClick={() =>
                setQty((current) => Math.min(acc.stock_quantity, current + 1))
              }
              className="h-12 w-12 rounded-xl border disabled:opacity-40"
              aria-label="Increase quantity"
            >
              +
            </button>
          </div>

          <p className="mt-2 text-xs text-gray-500">
            Available stock: {acc.stock_quantity}
          </p>
        </div>

        <div className="rounded-2xl border bg-[#EFF6FF] p-4">
          <div className="flex justify-between text-sm">
            <span>Unit Price</span>
            <span className="font-semibold">
              ₦{Number(acc.selling_price).toLocaleString()}
            </span>
          </div>

          <div className="mt-3 flex justify-between border-t pt-3">
            <span className="font-bold">Total</span>
            <span className="text-[22px] font-black text-[#2563EB]">
              ₦{total.toLocaleString()}
            </span>
          </div>
        </div>

        <div>
          <label className="text-[13px] font-semibold">Payment Method</label>

          <div className="mt-2 grid grid-cols-3 gap-2">
            {(['cash', 'transfer', 'pos'] as const).map((paymentMethod) => (
              <button
                key={paymentMethod}
                type="button"
                disabled={loading || outOfStock}
                onClick={() => setMethod(paymentMethod)}
                className={`rounded-xl border py-3 text-sm font-bold uppercase disabled:opacity-50 ${
                  method === paymentMethod
                    ? 'bg-black text-white'
                    : 'bg-white text-[#2563EB]'
                }`}
              >
                {paymentMethod}
              </button>
            ))}
          </div>
        </div>

        <button
          type="submit"
          disabled={loading || outOfStock}
          className="w-full rounded-xl bg-[#2563EB] py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-50"
        >
          {loading
            ? 'Processing...'
            : outOfStock
              ? 'Out of Stock'
              : `Confirm Sale — ₦${total.toLocaleString()}`}
        </button>
      </form>

      <SellSuccessPopup
        open={showSuccess}
        onClose={closeSuccess}
        data={saleData}
      />
    </>
  )
}
