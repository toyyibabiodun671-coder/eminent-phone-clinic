import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'
import Link from 'next/link'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  await getCurrentProfile()
  const supabase = await createClient()

  const { count: totalRepairs } = await supabase.from('repair_jobs').select('*', { count: 'exact', head: true })
  const { count: completed } = await supabase.from('repair_jobs').select('*', { count: 'exact', head: true }).eq('status', 'collected')
  const { count: pending } = await supabase.from('repair_jobs').select('*', { count: 'exact', head: true }).eq('status', 'diagnosing')

  const today = new Date().toISOString().split('T')[0]

  const { data: todayTxData } = await supabase
   .from('transactions')
   .select('id, amount, payment_method, transaction_type, description, created_at, transaction_date')
   .eq('transaction_date', today)
   .order('created_at', { ascending: false })

  const totalSales = todayTxData?.reduce((sum, s) => sum + Number(s.amount), 0) || 0
  const cash = todayTxData?.filter(s => s.payment_method === 'cash').reduce((sum, s) => sum + Number(s.amount), 0) || 0
  const transfer = todayTxData?.filter(s => s.payment_method === 'transfer').reduce((sum, s) => sum + Number(s.amount), 0) || 0
  const pos = todayTxData?.filter(s => s.payment_method === 'pos').reduce((sum, s) => sum + Number(s.amount), 0) || 0

  const repairPayments = todayTxData?.filter(s => ['repair','deposit','balance'].includes(s.transaction_type)).reduce((sum, s) => sum + Number(s.amount), 0) || 0
  const accessoryRevenue = todayTxData?.filter(s => s.transaction_type === 'accessory_sale').reduce((sum, s) => sum + Number(s.amount), 0) || 0
  const otherSales = totalSales - repairPayments - accessoryRevenue

  const { data: openRepairs } = await supabase.from('repair_jobs').select('repair_cost, amount_paid').neq('status', 'collected')
  const outstandingBalance = openRepairs?.reduce((sum, r) => sum + (Number(r.repair_cost) - Number(r.amount_paid || 0)), 0) || 0

  const cardClass = "rounded-2xl border border-blue-200 bg-white p-5 shadow-sm transition-all duration-200 hover:shadow-md hover:border-blue-300 hover:bg-[#EFF6FF]/50"

  return (
    <div className="min-h-screen bg-[#EFF6FF] -m-6 p-6">
      <div className="rounded-2xl bg-[#2563EB] p-6 shadow-lg">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/20 text-white font-bold">E</div>
          <div>
            <h1 className="text-2xl font-bold text-white">Dashboard</h1>
            <p className="mt-1 text-sm text-blue-100">Eminent Phone Clinic • Welcome back • {today}</p>
          </div>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        <div className={cardClass}>
          <p className="text-xs font-semibold uppercase tracking-wide text-[#2563EB]">Today Sales</p>
          <p className="mt-2 text-2xl font-bold text-[#1E3A8A]">₦{totalSales.toLocaleString()}</p>
          <p className="mt-1 text-[10px] leading-tight text-blue-500">Repair ₦{repairPayments.toLocaleString()} • Acc ₦{accessoryRevenue.toLocaleString()} • Other ₦{otherSales.toLocaleString()}</p>
        </div>
        <div className={cardClass}>
          <p className="text-xs font-semibold uppercase tracking-wide text-[#2563EB]">Accessories Today</p>
          <p className="mt-2 text-2xl font-bold text-[#1E3A8A]">₦{accessoryRevenue.toLocaleString()}</p>
          <p className="mt-1 text-xs text-blue-400">{todayTxData?.filter(s => s.transaction_type==='accessory_sale').length || 0} sales</p>
        </div>
        <div className={cardClass}>
          <p className="text-xs font-semibold uppercase tracking-wide text-[#2563EB]">Repairs</p>
          <p className="mt-2 text-2xl font-bold text-[#1E3A8A]">{totalRepairs?? 0}</p>
          <p className="mt-1 text-xs text-blue-400">Completed {completed?? 0} • Pending {pending?? 0}</p>
        </div>
        <div className={cardClass}>
          <p className="text-xs font-semibold uppercase tracking-wide text-[#2563EB]">Outstanding</p>
          <p className="mt-2 text-2xl font-bold text-amber-600">₦{outstandingBalance.toLocaleString()}</p>
          <p className="mt-1 text-xs text-blue-400">Customer balance</p>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-4">
        <div className="rounded-2xl border border-green-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-bold uppercase text-green-600">Cash</p>
          <p className="mt-2 text-xl font-bold text-green-700">₦{cash.toLocaleString()}</p>
        </div>
        <div className="rounded-2xl border border-purple-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-bold uppercase text-purple-600">Transfer</p>
          <p className="mt-2 text-xl font-bold text-purple-700">₦{transfer.toLocaleString()}</p>
        </div>
        <div className="rounded-2xl border border-orange-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-bold uppercase text-orange-600">POS</p>
          <p className="mt-2 text-xl font-bold text-orange-700">₦{pos.toLocaleString()}</p>
        </div>
      </div>

      <div className="mt-6 rounded-2xl border border-blue-200 bg-white p-5 shadow-sm">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-[#1E3A8A]">Today&apos;s Payments ({todayTxData?.length || 0}) — from transactions</h3>
          <Link href="/sales" className="text-xs font-semibold text-[#2563EB]">View All →</Link>
        </div>
        <div className="mt-4 divide-y divide-blue-50">
          {todayTxData && todayTxData.length > 0? (
            todayTxData.map((t) => (
              <div key={t.id} className="flex items-center justify-between py-3">
                <div>
                  <p className="text-sm font-medium text-gray-800">{t.description || t.transaction_type} <span className={`ml-2 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${t.transaction_type==='accessory_sale'? 'bg-[#2563EB] text-white' : 'bg-gray-100 text-gray-600'}`}>{t.transaction_type}</span></p>
                  <p className="text-xs text-gray-400">{new Date(t.created_at).toLocaleTimeString()} • <span className="font-bold uppercase">{t.payment_method}</span></p>
                </div>
                <span className="text-sm font-bold text-[#1E3A8A]">₦{Number(t.amount).toLocaleString()}</span>
              </div>
            ))
          ) : (
            <p className="py-8 text-center text-sm text-gray-400">No payments today yet — sell 2x USB-C Cable to test</p>
          )}
        </div>
      </div>

      <div className="mt-6 rounded-2xl border border-blue-200 bg-white p-5 shadow-sm">
        <h3 className="text-sm font-bold text-[#1E3A8A]">Quick Actions</h3>
        <div className="mt-4 flex flex-wrap gap-3">
          <Link href="/customers/new" className="rounded-xl bg-[#2563EB] px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-blue-700">+ New Customer</Link>
          <Link href="/repairs/new" className="rounded-xl border border-blue-200 bg-[#EFF6FF] px-5 py-2.5 text-sm font-semibold text-[#1D4ED8] hover:bg-blue-100">+ New Repair</Link>
          <Link href="/accessories/new" className="rounded-xl border border-blue-200 bg-white px-5 py-2.5 text-sm font-semibold text-[#1E3A8A] hover:bg-gray-50">+ New Accessory</Link>
          <Link href="/sales/new" className="rounded-xl border border-blue-200 bg-white px-5 py-2.5 text-sm font-semibold text-[#1E3A8A] hover:bg-gray-50">+ New Sale</Link>
        </div>
      </div>
    </div>
  )
}