'use client'

import { FormEvent, useState } from 'react'
import { useRouter } from 'next/navigation'

type Props = { repairId: string; outstanding: number }

export default function PaymentForm({ repairId, outstanding }: Props) {
  const router = useRouter()
  const [amount, setAmount] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('cash')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError(''); setSuccess('')
    const numericAmount = Number(amount)
    if (!numericAmount || numericAmount <= 0) { setError('Enter a valid payment amount.'); return }
    if (numericAmount > outstanding) { setError(`Cannot pay more than ₦${outstanding.toLocaleString()}`); return }
    setSaving(true)
    const response = await fetch(`/api/repairs/${repairId}/payment`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: numericAmount, payment_method: paymentMethod, description: 'Repair payment' }),
    })
    const result = await response.json()
    if (!response.ok) { setError(result.error || 'Unable to record payment.'); setSaving(false); return }
    setAmount('')
    setSuccess(`✅ Payment of ₦${numericAmount.toLocaleString()} recorded! Balance updated.`)
    setSaving(false)
    router.refresh()
  }

  if (outstanding <= 0) {
    return (
      <div className="rounded-2xl bg-green-50 border border-green-200 p-6 text-center">
        <div className="mx-auto w-12 h-12 rounded-full bg-green-500 text-white flex items-center justify-center text-xl">✓</div>
        <p className="mt-3 font-bold text-green-700">Fully Paid</p>
        <p className="text-sm text-green-600">This repair has been fully paid.</p>
      </div>
    )
  }

  // FIXED LINE 54 - now with commas
  const quickAmounts = [5000, 10000, 20000, outstanding].filter((v, i, arr) => v > 0 && v <= outstanding && arr.indexOf(v) === i)

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-[#1E3A8A] text-lg">Record Payment</h3>
        <span className="text-xs font-bold px-3 py-1.5 rounded-full bg-red-50 border border-red-200 text-red-600">Owes: ₦{outstanding.toLocaleString()}</span>
      </div>

      {/* QUICK AMOUNT BUTTONS - fixed */}
      <div className="flex flex-wrap gap-2">
        {quickAmounts.map((v) => (
          <button type="button" key={v} onClick={()=>setAmount(String(v))}
            className="rounded-full border border-blue-200 bg-white px-3 py-1 text-xs font-semibold text-[#2563EB] hover:bg-[#2563EB] hover:text-white transition-colors">
            ₦{v.toLocaleString()}
          </button>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-2 block text-sm font-semibold text-[#1D4ED8]">Payment Amount (₦)</label>
          <input type="number" min="1" max={outstanding} step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="e.g. 5000" required
            className="w-full rounded-xl border border-blue-200 bg-white px-4 py-3 outline-none focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 font-medium" />
        </div>
        <div>
          <label className="mb-2 block text-sm font-semibold text-[#1D4ED8]">Payment Method</label>
          <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}
            className="w-full rounded-xl border border-blue-200 bg-white px-4 py-3 outline-none focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 font-medium">
            <option value="cash">Cash</option>
            <option value="transfer">Bank Transfer</option>
            <option value="pos">POS</option>
            <option value="other">Other</option>
          </select>
        </div>
      </div>

      {error && <div className="rounded-xl bg-red-50 border border-red-200 p-3 text-sm text-red-600 font-medium">{error}</div>}
      {success && <div className="rounded-xl bg-blue-50 border border-blue-200 p-3 text-sm text-[#1D4ED8] font-medium">{success}</div>}

      <button type="submit" disabled={saving} className="w-full rounded-xl bg-[#2563EB] px-5 py-3.5 text-sm font-bold text-white shadow-md shadow-blue-200 hover:bg-blue-700 disabled:opacity-50 transition-all">
        {saving? 'Recording...' : `Record ₦${amount? Number(amount).toLocaleString() : '0'} Payment`}
      </button>
    </form>
  )
}