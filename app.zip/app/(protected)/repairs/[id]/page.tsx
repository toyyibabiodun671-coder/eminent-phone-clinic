import PaymentForm from './payment-form'
import { notFound } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'
import StatusControl from '@/components/repairs/status-control'

type SalePayment = {
  id: string
  amount: string | number
  payment_method: string
  sale_date: string
  created_at: string
}

export default async function RepairDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const result = await getCurrentProfile()
  const profile = result?.profile
  if (!profile) return notFound()

  const supabase = await createClient()
  const { data: repair, error } = await supabase
.from('repair_jobs')
.select(`*, customers (full_name, phone, email, address), devices (brand, model, device_type, imei, serial_number, color, condition_notes), technician:profiles!repair_jobs_technician_id_fkey (full_name)`)
.eq('id', id)
.single()

  if (error ||!repair) return notFound()

  // FIXED: Read from sales table per Rule 7.13
  const { data: payments } = await supabase.from('sales').select('*').eq('repair_job_id', id).in('type', ['repair','deposit','balance']).order('created_at', { ascending: false })

  const customer = Array.isArray(repair.customers)? repair.customers[0] : repair.customers
  const device = Array.isArray(repair.devices)? repair.devices[0] : repair.devices
  const technician = Array.isArray(repair.technician)? repair.technician[0] : repair.technician

  const repairCost = Number(repair.repair_cost || 0)
  const paymentList = (payments as SalePayment[] | null)?? []
  const amountPaid = paymentList.reduce((sum: number, p: SalePayment) => sum + Number(p.amount), 0)
  const outstanding = Math.max(repairCost - amountPaid, 0)

  const isAdmin = profile.role === 'admin' || (profile.role as string) === 'manager'

  return (
    <div className="mx-auto max-w-5xl p-6">
      <div className="rounded-xl bg-[#2563EB] p-6 text-white shadow-md">
        <h1 className="text-2xl font-bold text-white">Repair Details</h1>
        <p className="mt-2 text-sm text-blue-100">View and manage this repair job — #{repair.id.slice(0,8)}</p>
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <section className="rounded-2xl border border-blue-200 bg-[#EFF6FF] p-6 shadow-sm">
          <h2 className="text-lg font-bold text-[#1E3A8A]">Customer</h2>
          <div className="mt-4 space-y-2 text-sm text-slate-700">
            <p><strong className="text-[#2563EB]">Name:</strong> {customer?.full_name}</p>
            <p><strong className="text-[#2563EB]">Phone:</strong> {customer?.phone}</p>
            <p><strong className="text-[#2563EB]">Email:</strong> {customer?.email || '—'}</p>
          </div>
        </section>

        <section className="rounded-2xl border border-blue-200 bg-[#EFF6FF] p-6 shadow-sm">
          <h2 className="text-lg font-bold text-[#1E3A8A]">Device</h2>
          <div className="mt-4 space-y-2 text-sm text-slate-700">
            <p><strong className="text-[#2563EB]">Device:</strong> {device?.brand} {device?.model}</p>
            <p><strong className="text-[#2563EB]">Type:</strong> {device?.device_type}</p>
            <p><strong className="text-[#2563EB]">IMEI:</strong> {device?.imei || '—'}</p>
            <p><strong className="text-[#2563EB]">Serial:</strong> {device?.serial_number || '—'}</p>
          </div>
        </section>

        <section className="rounded-2xl border border-blue-200 bg-[#EFF6FF] p-6 shadow-sm">
          <h2 className="text-lg font-bold text-[#1E3A8A]">Repair</h2>
          <div className="mt-4 space-y-4 text-sm">
            <div><p className="text-xs font-semibold text-[#2563EB]">Problem Reported</p><p className="mt-1 text-slate-700">{repair.problem_description || repair.issue_description || 'No description'}</p></div>
            <div><p className="text-xs font-semibold text-[#2563EB]">Diagnosis</p><p className="mt-1 text-slate-700">{repair.diagnosis || 'Not diagnosed yet'}</p></div>
            <div><p className="text-xs font-semibold text-[#2563EB]">Technician</p><p className="mt-1 font-medium text-slate-700">{technician?.full_name || 'Unassigned'}</p></div>
          </div>
        </section>

        <section className="rounded-2xl border border-blue-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-bold text-[#1E3A8A]">Financial Information</h2>
          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="rounded-xl bg-[#EFF6FF] p-4 border border-blue-100"><p className="text-xs font-semibold text-[#2563EB]">Repair Cost</p><p className="mt-1 text-xl font-bold text-[#1E3A8A]">₦{repairCost.toLocaleString()}</p></div>
            <div className="rounded-xl bg-green-50 p-4 border border-green-200"><p className="text-xs font-semibold text-green-700">Paid</p><p className="mt-1 text-xl font-bold text-green-600">₦{amountPaid.toLocaleString()}</p></div>
            <div className="col-span-2 rounded-xl bg-[#2563EB] p-4 shadow-md"><p className="text-xs text-blue-100">Outstanding</p><p className="mt-1 text-2xl font-bold text-white">₦{outstanding.toLocaleString()}</p></div>
          </div>
        </section>
      </div>

      <section className="mt-5"><PaymentForm repairId={repair.id} outstanding={outstanding} /></section>

      <section className="mt-5 rounded-2xl border border-blue-200 bg-[#EFF6FF] p-5 shadow-sm">
        <h3 className="font-bold mb-3 text-[#1E3A8A]">Payment History (from sales table)</h3>
        {paymentList.length === 0? <p className="text-sm text-[#2563EB]">No payments yet</p> :
        paymentList.map((p: SalePayment) => (
          <div key={p.id} className="flex justify-between py-3 border-b border-blue-100 text-sm">
            <span className="text-slate-600">{new Date(p.sale_date || p.created_at).toLocaleDateString()} - <span className="capitalize font-medium text-[#2563EB]">{p.payment_method}</span></span>
            <span className="font-bold text-[#1D4ED8]">₦{Number(p.amount).toLocaleString()}</span>
          </div>
        ))}
      </section>

      <section className="mt-5 rounded-2xl border border-blue-200 bg-white p-6 shadow-sm">
        <StatusControl repairId={repair.id} currentStatus={repair.status} isAdmin={isAdmin} />
      </section>
    </div>
  )
}