import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'

export default async function RepairsPage() {
    const { profile } = await getCurrentProfile()
    const supabase = await createClient()

  let query = supabase
  .from('repair_jobs')
  .select(`id, problem_description, repair_cost, amount_paid, status, date_received, customers (full_name, phone), devices (brand, model), technician:profiles!repair_jobs_technician_id_fkey (full_name)`)

  if (profile.role === 'apprentice') { query = query.eq('technician_id', profile.id) }

  const { data: repairs, error } = await query.order('date_received', { ascending: false })
  if (error) throw new Error('Unable to load repair jobs.')

  return (
    <div className="p-6">
      {/* BLUE HEADER LIKE DASHBOARD */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between rounded-xl bg-[#2563EB] p-5 text-white shadow-md">
        <div>
          <h1 className="text-2xl font-bold text-white sm:text-3xl">Repair Jobs</h1>
          <p className="mt-2 text-sm text-blue-100">Track customer devices from intake to collection.</p>
        </div>
        <Link href="/repairs/new" className="inline-flex items-center justify-center rounded-lg bg-white px-4 py-3 text-sm font-semibold text-[#2563EB] hover:bg-blue-50">
          + New Repair Job
        </Link>
      </div>

      <div className="mt-6 overflow-hidden rounded-2xl border border-blue-200 bg-[#EFF6FF] shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[950px] text-left">
            <thead className="bg-[#2563EB] text-white">
              <tr>
                <th className="px-5 py-4 text-sm font-semibold text-white">Customer</th>
                <th className="px-5 py-4 text-sm font-semibold text-white">Device</th>
                <th className="px-5 py-4 text-sm font-semibold text-white">Problem</th>
                <th className="px-5 py-4 text-sm font-semibold text-white">Technician</th>
                <th className="px-5 py-4 text-sm font-semibold text-white">Status</th>
                <th className="px-5 py-4 text-sm font-semibold text-white">Balance</th>
              </tr>
            </thead>
            <tbody>
              {repairs?.map((repair) => {
                const customer = Array.isArray(repair.customers)? repair.customers[0] : repair.customers
                const device = Array.isArray(repair.devices)? repair.devices[0] : repair.devices
                const technician = Array.isArray(repair.technician)? repair.technician[0] : repair.technician
                const balance = Number(repair.repair_cost) - Number(repair.amount_paid)
                return (
                  <tr key={repair.id} className="border-b border-blue-100 transition-colors hover:bg-[#DBEAFE]">
                    <td className="px-5 py-4">
                      <Link href={`/repairs/${repair.id}`} className="hover:underline">
                        <p className="text-sm font-medium text-[#1D4ED8]">{customer?.full_name || 'Unknown'}</p>
                        <p className="text-xs text-[#2563EB]">{customer?.phone || '—'}</p>
                      </Link>
                    </td>
                    <td className="px-5 py-4 text-sm text-slate-700">{device?.brand} {device?.model}</td>
                    <td className="max-w-[220px] px-5 py-4 text-sm text-slate-700">{repair.problem_description}</td>
                    <td className="px-5 py-4 text-sm text-slate-700">{technician?.full_name || 'Unassigned'}</td>
                    <td className="px-5 py-4">
                      <span className="rounded-full bg-[#2563EB] px-3 py-1 text-xs font-medium capitalize text-white">
                        {repair.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-sm font-bold text-[#1D4ED8]">₦{balance.toLocaleString()}</td>
                  </tr>
                )
              })}
              {(!repairs || repairs.length === 0) && (
                <tr><td colSpan={6} className="px-5 py-10 text-center text-sm text-[#2563EB]">No repair jobs registered yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}