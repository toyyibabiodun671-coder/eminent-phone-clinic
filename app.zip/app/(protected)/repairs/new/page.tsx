'use client'
import { FormEvent, useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

type Customer = { id: string; full_name: string; phone: string }
type Technician = { id: string; full_name: string; role: string }
type Device = { id: string; customer_id: string; brand: string; model: string; imei: string | null }

export default function NewRepairPage() {
  const router = useRouter()
  const supabase = createClient()
  const [customers, setCustomers] = useState<Customer[]>([])
  const [devices, setDevices] = useState<Device[]>([])
  const [technicians, setTechnicians] = useState<Technician[]>([])
  const [technicianId, setTechnicianId] = useState('')
  const [customerId, setCustomerId] = useState('')
  const [deviceId, setDeviceId] = useState('')
  const [problem, setProblem] = useState('')
  const [diagnosis, setDiagnosis] = useState('')
  const [repairCost, setRepairCost] = useState('')
  const [amountPaid, setAmountPaid] = useState('')
  const [expectedCompletion, setExpectedCompletion] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('customers').select('id, full_name, phone').order('full_name')
      setCustomers(data || [])
      const { data: techData } = await supabase.from('profiles').select('id, full_name, role').in('role', ['apprentice','technician','admin','owner']).order('full_name')
      setTechnicians(techData || [])
      setLoading(false)
    })()
  }, [])

  useEffect(() => {
    (async () => {
      if (!customerId) { setDevices([]); setDeviceId(''); return }
      const { data } = await supabase.from('devices').select('id, customer_id, brand, model, imei').eq('customer_id', customerId).order('created_at', { ascending: false })
      setDevices(data || [])
      setDeviceId('')
    })()
  }, [customerId])

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError('')
    if (!customerId) { setError('Please select a customer.'); return }
    if (!deviceId) { setError('Please select a device.'); return }
    const totalCost = Number(repairCost || 0)
    const paid = Number(amountPaid || 0)
    if (paid > totalCost) { setError('Amount paid cannot be greater than repair cost.'); return }
    setSaving(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push('/login'); return }

      // NO NEWLINE - fixes red at 106
      const { data: job, error: insertError } = await supabase.from('repair_jobs').insert({ customer_id: customerId, device_id: deviceId, technician_id: technicianId || null, problem_description: problem.trim(), diagnosis: diagnosis.trim() || null, repair_cost: totalCost, amount_paid: paid, expected_completion: expectedCompletion || null, created_by: user.id }).select('id').single()

      if (insertError) throw new Error(insertError.message)
      if (!job) throw new Error('Failed to create job')

      // Rule 7.13 - insert to sales (only columns from your screenshot)
      if (paid > 0) {
        const { error: salesError } = await supabase.from('sales').insert({ amount: paid, type: paid < totalCost? 'deposit' : 'repair', payment_method: 'cash', customer_id: customerId, repair_job_id: job.id, device_id: deviceId, description: `Down payment for repair #${job.id.slice(0, 8)}` })
        if (salesError) console.log('SALES ERROR:', salesError.message)
      }

      router.push('/repairs')
      router.refresh()
    } catch (err: any) {
      setError(err.message)
      setSaving(false)
    }
  }

  const balance = Number(repairCost || 0) - Number(amountPaid || 0)
  const inputClass = "w-full rounded-lg border border-blue-200 bg-white px-4 py-3 outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100"
  const labelClass = "mb-2 block text-sm font-medium text-[#1D4ED8]"

  return (
    <div className="mx-auto max-w-3xl p-6">
      <div className="rounded-xl bg-[#2563EB] p-5 text-white shadow-md">
        <h1 className="text-2xl font-bold">New Repair Job</h1>
        <p className="mt-2 text-sm text-blue-100">Register a device for repair.</p>
      </div>
      <form onSubmit={handleSubmit} className="mt-6 rounded-2xl border border-blue-200 bg-[#EFF6FF] p-5 shadow-sm sm:p-7">
        <div className="grid gap-5">
          <div><label className={labelClass}>Customer *</label><select value={customerId} onChange={(e) => setCustomerId(e.target.value)} required disabled={loading} className={inputClass}><option value="">{loading? 'Loading...' : 'Select customer'}</option>{customers.map((c) => <option key={c.id} value={c.id}>{c.full_name} — {c.phone}</option>)}</select></div>
          <div><label className={labelClass}>Device * {devices.length > 0 && `(${devices.length} found)`}</label><select value={deviceId} onChange={(e) => setDeviceId(e.target.value)} required disabled={!customerId} className={`${inputClass} disabled:opacity-50`}><option value="">{!customerId? 'Select a customer first' : devices.length === 0? 'No devices' : 'Select device'}</option>{devices.map((d) => <option key={d.id} value={d.id}>{d.brand} {d.model} {d.imei? `— ${d.imei}` : ''}</option>)}</select></div>
          <div><label className={labelClass}>Problem Reported *</label><textarea value={problem} onChange={(e) => setProblem(e.target.value)} required rows={4} placeholder="Describe complaint..." className={inputClass} /></div>
          <div><label className={labelClass}>Diagnosis</label><textarea value={diagnosis} onChange={(e) => setDiagnosis(e.target.value)} rows={3} placeholder="Diagnosis..." className={inputClass} /></div>
          <div><label className={labelClass}>Assign Technician</label><select value={technicianId} onChange={(e) => setTechnicianId(e.target.value)} className={inputClass}><option value="">Unassigned</option>{technicians.map((t) => <option key={t.id} value={t.id}>{t.full_name}</option>)}</select></div>
          <div className="grid gap-5 sm:grid-cols-2"><div><label className={labelClass}>Repair Cost (₦)</label><input type="number" min="0" step="0.01" value={repairCost} onChange={(e) => setRepairCost(e.target.value)} className={inputClass} /></div><div><label className={labelClass}>Amount Paid (₦)</label><input type="number" min="0" step="0.01" value={amountPaid} onChange={(e) => setAmountPaid(e.target.value)} className={inputClass} /></div></div>
          <div className="rounded-xl bg-[#2563EB] p-4 text-white"><p className="text-sm text-blue-100">Outstanding Balance</p><p className="mt-1 text-2xl font-bold">₦{balance.toLocaleString()}</p></div>
          <div><label className={labelClass}>Expected Completion</label><input type="date" value={expectedCompletion} onChange={(e) => setExpectedCompletion(e.target.value)} className={inputClass} /></div>
        </div>
        {error && <div className="mt-5 rounded-lg bg-red-50 p-3 text-sm text-red-600">{error}</div>}
        <div className="mt-7 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
          <button type="button" onClick={() => router.back()} className="rounded-lg border border-blue-200 bg-white px-5 py-3 text-sm font-semibold text-[#2563EB]">Cancel</button>
          <button type="submit" disabled={saving} className="rounded-lg bg-[#2563EB] px-5 py-3 text-sm font-semibold text-white disabled:opacity-50">{saving? 'Saving...' : 'Create Repair Job'}</button>
        </div>
      </form>
    </div>
  )
}