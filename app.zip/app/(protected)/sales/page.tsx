import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'

type SaleRow = {
  id: string
  type: string
  description: string | null
  amount: string | number
  payment_method: string
  sale_date: string
  created_at: string
  repair_job_id: string | null
}

export default async function SalesPage() {
  await getCurrentProfile()

  const supabase = await createClient()

  // FIXED: Removed profiles join - FK does not exist in schema cache
  // Rule 7.13 - All sales must come from sales table
  const { data: sales, error } = await supabase
   .from('sales')
   .select(`
      id,
      type,
      description,
      amount,
      payment_method,
      sale_date,
      created_at,
      repair_job_id
    `)
   .order('sale_date', {
      ascending: false,
    })

  if (error) {
    console.log('SALES PAGE ERROR:', error)
    throw new Error('Unable to load sales: ' + error.message)
  }

  const totalSales =
    sales?.reduce(
      (total, sale) =>
        total + Number(sale.amount),
      0
    ) || 0

  return (
    <div className="p-6">
      {/* BLUE HEADER - like Repairs */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between rounded-xl bg-[#2563EB] p-5 text-white shadow-md">
        <div>
          <h1 className="text-2xl font-bold text-white sm:text-3xl">
            Sales
          </h1>
          <p className="mt-2 text-sm text-blue-100">
            Record and monitor money received by the workshop
          </p>
        </div>

        <Link
          href="/sales/new"
          className="inline-flex items-center justify-center rounded-lg bg-white px-4 py-3 text-sm font-semibold text-[#2563EB] hover:bg-blue-50 shadow-md"
        >
          + Record Sale
        </Link>
      </div>

      {/* TOTAL CARD BLUE */}
      <div className="mt-6 rounded-2xl border border-blue-200 bg-[#EFF6FF] p-6 shadow-sm">
        <p className="text-sm font-medium text-[#2563EB]">
          Total Recorded Sales (from sales table)
        </p>
        <p className="mt-2 text-3xl font-bold text-[#1E3A8A]">
          ₦{totalSales.toLocaleString()}
        </p>
      </div>

      {/* TABLE BLUE */}
      <div className="mt-6 overflow-hidden rounded-2xl border border-blue-200 bg-[#EFF6FF] shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[850px] text-left">
            <thead className="bg-[#2563EB] text-white">
              <tr>
                <th className="px-5 py-4 text-sm font-semibold text-white">
                  Description
                </th>
                <th className="px-5 py-4 text-sm font-semibold text-white">
                  Type
                </th>
                <th className="px-5 py-4 text-sm font-semibold text-white">
                  Amount
                </th>
                <th className="px-5 py-4 text-sm font-semibold text-white">
                  Payment
                </th>
                <th className="px-5 py-4 text-sm font-semibold text-white">
                  Date
                </th>
              </tr>
            </thead>

            <tbody>
              {(sales as SaleRow[])?.map((sale) => (
                <tr
                  key={sale.id}
                  className="border-b border-blue-100 transition-colors hover:bg-[#DBEAFE]"
                >
                  <td className="px-5 py-4 text-sm font-medium text-slate-700">
                    {sale.description || '—'}
                  </td>
                  <td className="px-5 py-4 text-sm capitalize">
                    <span className="rounded-full bg-[#2563EB] px-3 py-1 text-xs font-medium capitalize text-white">
                      {sale.type?.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-sm font-bold text-[#1D4ED8]">
                    ₦{Number(sale.amount).toLocaleString()}
                  </td>
                  <td className="px-5 py-4 text-sm capitalize text-slate-600">
                    {sale.payment_method}
                  </td>
                  <td className="px-5 py-4 text-sm text-[#2563EB]">
                    {new Date(sale.sale_date || sale.created_at).toLocaleDateString()}
                  </td>
                </tr>
              ))}

              {(!sales || sales.length === 0) && (
                <tr>
                  <td
                    colSpan={5}
                    className="px-5 py-10 text-center text-sm text-[#2563EB]"
                  >
                    No sales recorded yet. New payments will appear here via sales table.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}