import Link from 'next/link'
import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { getCurrentProfile } from '@/lib/auth/get-profile'

export default async function NewDevicePage({
  searchParams,
}: {
  searchParams: Promise<{
    customer_id?: string
  }>
}) {
  await getCurrentProfile()

  const params = await searchParams
  const customerId = params.customer_id

  if (!customerId) {
    redirect('/customers')
  }

  const supabase = await createClient()

  const { data: customer, error } = await supabase
    .from('customers')
    .select('id, full_name, phone')
    .eq('id', customerId)
    .single()

  if (error || !customer) {
    redirect('/customers')
  }

  return (
    <div className="min-h-screen bg-[#EFF6FF] -m-6 p-6">
      <div className="mx-auto max-w-3xl">
        <div className="mb-6">
          <Link
            href={`/customers/${customer.id}`}
            className="text-sm font-semibold text-[#2563EB] hover:underline"
          >
            ← Back to Customer
          </Link>
          <h1 className="mt-4 text-2xl font-bold text-[#1E3A8A] sm:text-3xl">
            Register Device
          </h1>
          <p className="mt-2 text-sm text-[#1D4ED8]">
            Register a device for {customer.full_name}.
          </p>
        </div>

        <div className="rounded-2xl border border-blue-200 bg-white p-5 shadow-sm sm:p-7">
          <div className="mb-6 rounded-xl bg-[#EFF6FF] border border-blue-200 p-4">
            <p className="text-xs font-semibold text-[#1D4ED8]">Customer</p>
            <p className="mt-1 font-bold text-[#1E3A8A]">{customer.full_name}</p>
            <p className="mt-1 text-sm text-slate-600">{customer.phone}</p>
          </div>

          <form
            action="/api/devices/create"
            method="POST"
            className="space-y-5"
          >
            <input type="hidden" name="customer_id" value={customer.id} />

            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-semibold text-[#1E3A8A]">
                  Brand *
                </label>
                <input
                  name="brand"
                  required
                  placeholder="Samsung"
                  className="w-full rounded-xl border border-blue-200 bg-white px-4 py-3 text-sm outline-none focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100"
                />
              </div>
              <div>
                <label className="mb-2 block text-sm font-semibold text-[#1E3A8A]">
                  Model *
                </label>
                <input
                  name="model"
                  required
                  placeholder="Galaxy S24"
                  className="w-full rounded-xl border border-blue-200 bg-white px-4 py-3 text-sm outline-none focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100"
                />
              </div>
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-semibold text-[#1E3A8A]">
                  Device Type *
                </label>
                <select
                  name="device_type"
                  className="w-full rounded-xl border border-blue-200 bg-white px-4 py-3 text-sm outline-none focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100"
                >
                  <option value="phone">Phone</option>
                  <option value="tablet">Tablet</option>
                  <option value="laptop">Laptop</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label className="mb-2 block text-sm font-semibold text-[#1E3A8A]">
                  Color
                </label>
                <input
                  name="color"
                  placeholder="Black"
                  className="w-full rounded-xl border border-blue-200 bg-white px-4 py-3 text-sm outline-none focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100"
                />
              </div>
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-semibold text-[#1E3A8A]">
                  IMEI
                </label>
                <input
                  name="imei"
                  placeholder="IMEI number"
                  className="w-full rounded-xl border border-blue-200 bg-white px-4 py-3 text-sm outline-none focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100"
                />
              </div>
              <div>
                <label className="mb-2 block text-sm font-semibold text-[#1E3A8A]">
                  Serial Number
                </label>
                <input
                  name="serial_number"
                  placeholder="Serial number"
                  className="w-full rounded-xl border border-blue-200 bg-white px-4 py-3 text-sm outline-none focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100"
                />
              </div>
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold text-[#1E3A8A]">
                Device Condition / Notes
              </label>
              <textarea
                name="condition_notes"
                rows={4}
                placeholder="Cracked screen, missing back cover, etc."
                className="w-full rounded-xl border border-blue-200 bg-white px-4 py-3 text-sm outline-none focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100"
              />
            </div>

            <div className="flex flex-col gap-3 sm:flex-row sm:justify-end pt-2">
              <Link
                href={`/customers/${customer.id}`}
                className="rounded-xl border border-blue-200 bg-white px-5 py-3 text-center text-sm font-semibold text-[#1E3A8A] hover:bg-[#EFF6FF]"
              >
                Cancel
              </Link>
              <button
                type="submit"
                className="rounded-xl bg-[#2563EB] px-6 py-3 text-sm font-semibold text-white shadow-md shadow-blue-200 hover:bg-blue-700"
              >
                Save Device
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}