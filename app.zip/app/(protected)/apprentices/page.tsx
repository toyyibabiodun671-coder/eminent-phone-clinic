import { requireAdmin } from '@/lib/auth/require-admin'

export default async function ApprenticesPage() {
  const { profile } = await requireAdmin()

  return (
    <main className="min-h-screen bg-[#EFF6FF] p-6">
      <div className="mx-auto max-w-6xl">
        {/* BLUE HEADER LIKE LOGIN */}
        <div className="rounded-2xl bg-[#2563EB] p-8 shadow-lg">
          <h1 className="text-3xl font-bold text-white">
            Apprentices
          </h1>
          <p className="mt-2 text-blue-100">
            Welcome, {profile.full_name}.
          </p>
        </div>

        <div className="mt-6 rounded-2xl border border-blue-200 bg-white p-6 shadow-sm">
          <h2 className="text-sm font-semibold text-[#1D4ED8] uppercase tracking-wide">Management</h2>
          <p className="mt-3 text-slate-700">
            Apprentice management will be built here.
          </p>
          {/* Example blue button */}
          <button className="mt-5 rounded-lg bg-[#2563EB] px-5 py-2.5 font-semibold text-white shadow-md hover:bg-blue-700 transition-all">
            Add Apprentice
          </button>
        </div>
      </div>
    </main>
  )
}