import { getCurrentProfile } from '@/lib/auth/get-profile'
import { Sidebar } from '@/components/navigation/sidebar'
import { Header } from '@/components/layout/header'

export default async function ProtectedLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { profile } = await getCurrentProfile()

  return (
    <div className="min-h-screen bg-[#EFF6FF]">
      <Header
        name={profile.full_name}
        role={profile.role}
      />

      <div className="flex">
        <Sidebar role={profile.role} />

        <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-8 bg-[#EFF6FF]">
          {children}
        </main>
      </div>
    </div>
  )
}